package com.shaikh.seamless

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private val Black = Color(0xFF08090B)
private val Surface = Color(0xFF15171B)
private val Peach = Color(0xFFFFA17A)
private val Pink = Color(0xFFEA72B5)
private val Blue = Color(0xFF6B8CFF)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { SeamlessApp(player!!) }
    }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

@Composable
private fun SeamlessApp(player: ExoPlayer) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selected by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var permission by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(true) }
    var glass by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(0) }
    var visualizer by remember { mutableIntStateOf(0) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val permissionName = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    fun scan() {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val found = mutableListOf<Track>()
        val cursor: Cursor? = context.contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")
        cursor?.use { c ->
            val idCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST); val durCol=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while(c.moveToNext()) { val id=c.getLong(idCol); found += Track(id,c.getString(titleCol) ?: "Unknown track",c.getString(artistCol) ?: "Unknown artist",ContentUris.withAppendedId(collection,id),c.getLong(durCol)) }
        }
        tracks = found
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> permission=granted; if(granted) scan() }
    LaunchedEffect(Unit) {
        permission = ContextCompat.checkSelfPermission(context, permissionName) == PackageManager.PERMISSION_GRANTED
        if(permission) scan()
    }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing=isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { selected=player.currentMediaItemIndex }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) { while(true) { position=player.currentPosition.coerceAtLeast(0); duration=player.duration.takeIf { it > 0 } ?: 0L; delay(400) } }
    val bg = if(dark) Black else Color(0xFFF3F1EF)
    val fg = if(dark) Color.White else Color(0xFF171719)
    MaterialTheme(colorScheme = darkColorScheme(background=bg, surface=Surface, primary=Peach, onBackground=fg, onSurface=Color.White)) {
        Column(Modifier.fillMaxSize().background(bg).padding(horizontal=20.dp)) {
            Row(Modifier.fillMaxWidth().padding(top=22.dp,bottom=18.dp), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("SEAMLESS", color=fg, fontSize=20.sp, fontWeight=FontWeight.Bold, letterSpacing=3.sp); Text("Your music, uninterrupted", color=fg.copy(alpha=.55f), fontSize=12.sp) }
                IconButton(onClick={ dark=!dark }) { Icon(if(dark) Icons.Default.LightMode else Icons.Default.DarkMode,null,tint=fg) }
                IconButton(onClick={ glass=!glass }) { Icon(Icons.Default.Tune,null,tint=fg) }
            }
            if(glass) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface).padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text("Liquid Glass",Modifier.weight(1f),color=Color.White); Text("Visual style",color=Color.LightGray,fontSize=12.sp)
                }
                Spacer(Modifier.height(12.dp))
            }
            Box(Modifier.fillMaxWidth().weight(.95f),contentAlignment=Alignment.Center) {
                Canvas(Modifier.size(250.dp)) {
                    val center=Offset(size.width/2,size.height/2); val radius=size.minDimension*.37f
                    drawCircle(Brush.sweepGradient(listOf(Peach,Pink,Blue,Peach)),radius=radius,center=center,style=Stroke(width=7.dp.toPx(),cap=StrokeCap.Round))
                    drawCircle(Color.White.copy(alpha=.04f),radius=radius-18.dp.toPx(),center=center)
                    val bars=48
                    for(i in 0 until bars) {
                        val a=(i.toFloat()/bars)*Math.PI*2
                        val inner=radius+12.dp.toPx(); val outer=inner+(if(i%3==0) 13.dp else 6.dp).toPx()
                        drawLine(Brush.linearGradient(listOf(Peach,Blue)),Offset(center.x+kotlin.math.cos(a).toFloat()*inner,center.y+kotlin.math.sin(a).toFloat()*inner),Offset(center.x+kotlin.math.cos(a).toFloat()*outer,center.y+kotlin.math.sin(a).toFloat()*outer),2.dp.toPx(),StrokeCap.Round)
                    }
                }
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(if(selected in tracks.indices) tracks[selected].title else "SEAMLESS",color=fg,fontSize=17.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Text(if(selected in tracks.indices) tracks[selected].artist else "Choose a track",color=fg.copy(alpha=.55f),fontSize=12.sp)
                }
            }
            Slider(value=if(duration>0) position.toFloat().coerceIn(0f,duration.toFloat()) else 0f,onValueChange={ if(duration>0) player.seekTo(it.toLong()) },valueRange=0f..(duration.coerceAtLeast(1).toFloat()),colors=SliderDefaults.colors(thumbColor=Peach,activeTrackColor=Peach,inactiveTrackColor=fg.copy(alpha=.2f)))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(time(position),color=fg.copy(alpha=.5f),fontSize=11.sp); Text(time(duration),color=fg.copy(alpha=.5f),fontSize=11.sp) }
            Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={shuffle=!shuffle;player.shuffleModeEnabled=shuffle}) { Icon(Icons.Default.Shuffle,null,tint=if(shuffle) Peach else fg.copy(alpha=.6f)) }
                IconButton(onClick={ player.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious,null,tint=fg,modifier=Modifier.size(34.dp)) }
                IconButton(onClick={ if(player.isPlaying) player.pause() else player.play() },modifier=Modifier.size(68.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Peach,Pink)))) { Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=Black,modifier=Modifier.size(38.dp)) }
                IconButton(onClick={ player.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext,null,tint=fg,modifier=Modifier.size(34.dp)) }
                IconButton(onClick={ repeat=(repeat+1)%3;player.repeatMode=when(repeat){1->Player.REPEAT_MODE_ONE;2->Player.REPEAT_MODE_ALL;else->Player.REPEAT_MODE_OFF} }) { Icon(Icons.Default.Repeat,null,tint=if(repeat!=0) Peach else fg.copy(alpha=.6f)) }
            }
            Row(Modifier.fillMaxWidth().padding(top=8.dp,bottom=8.dp),verticalAlignment=Alignment.CenterVertically) {
                Text("LIBRARY",color=fg,fontWeight=FontWeight.Bold,letterSpacing=2.sp,fontSize=12.sp,modifier=Modifier.weight(1f))
                Text("${tracks.size} tracks",color=fg.copy(alpha=.5f),fontSize=11.sp)
                TextButton(onClick={ if(permission) scan() else launcher.launch(permissionName) }) { Text("SCAN",color=Peach,fontSize=11.sp) }
            }
            if(!permission) {
                Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) { Button(onClick={launcher.launch(permissionName)}) { Text("Allow music access") } }
            } else if(tracks.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center) { Text("No local music found",color=fg.copy(alpha=.55f)) }
            } else {
                LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(bottom=22.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    itemsIndexed(tracks,key={_,t->t.id}) { index,track ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if(index==selected) Surface else Color.Transparent).clickable {
                            selected=index; player.setMediaItems(tracks.map { MediaItem.fromUri(it.uri) },index,0L); player.prepare(); player.play()
                        }.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(Color(0xFF28242A),Color(0xFF171B25)))),contentAlignment=Alignment.Center) { Icon(Icons.Default.MusicNote,null,tint=Peach) }
                            Column(Modifier.weight(1f).padding(start=12.dp)) { Text(track.title,color=fg,fontWeight=FontWeight.Medium,maxLines=1,overflow=TextOverflow.Ellipsis); Text(track.artist,color=fg.copy(alpha=.5f),fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis) }
                            Text(time(track.duration),color=fg.copy(alpha=.45f),fontSize=11.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun time(ms: Long): String { val s=(ms.coerceAtLeast(0)/1000); return "%d:%02d".format(s/60,s%60) }
